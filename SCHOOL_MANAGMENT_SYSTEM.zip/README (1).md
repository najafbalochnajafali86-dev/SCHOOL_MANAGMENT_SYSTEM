# 🎓 VIP School Management System Dashboard

A fully advanced and colorful School Management System built using
**Python, Tkinter, and SQLite**.

This project is developed for academic and professional learning
purposes under:

**PITP -- MUET Sindh Government Initiative**\
(Mehran University of Engineering & Technology -- Sindh Government)

------------------------------------------------------------------------

## 🏛 Institutional Affiliation

This project is associated with:

-   PITP (Punjab Information Technology Program / Training Initiative
    Context)
-   MUET (Mehran University of Engineering & Technology)
-   Government of Sindh

------------------------------------------------------------------------

## 🚀 Features

✅ Colorful VIP Dashboard\
✅ Sidebar Navigation Panel\
✅ Student Management System\
✅ Teacher Management System\
✅ Live Student Count\
✅ Live Teacher Count\
✅ SQLite Database Integration\
✅ Professional GUI Layout

------------------------------------------------------------------------

## 🛠 Technologies Used

-   Python 3.x
-   Tkinter (GUI)
-   SQLite3 (Database)
-   VS Code (Recommended IDE)

------------------------------------------------------------------------

## 📂 Project Structure

vip_school_dashboard.py\
vip_school.db (auto-created after running)\
README.md

------------------------------------------------------------------------

## ▶ How To Run The Project

1.  Install Python (3.x)
2.  Open project folder in VS Code
3.  Open Terminal
4.  Run:

python vip_school_dashboard.py

------------------------------------------------------------------------

## 🖥 Dashboard Overview

### 📊 Dashboard

-   Displays total number of students
-   Displays total number of teachers
-   Modern colorful cards design

### 👨‍🎓 Student Section

-   Add Student
-   View Students
-   Data stored in database

### 👨‍🏫 Teacher Section

-   Add Teacher
-   View Teachers
-   Data stored in database

------------------------------------------------------------------------

## 💾 Database

Database file: vip_school.db

Tables: - students - teachers

Tables are automatically created on first run.

------------------------------------------------------------------------

## 🌐 Connect With Me

GitHub: https://github.com/najafbalochnajafali86_dev\
Fiverr: https://www.fiverr.com/najaf_baloch12\
LinkedIn: https://www.linkedin.com/in/Najaf_Baloch


------------------------------------------------------------------------

## 👨‍💻 Developed By

Najaf Ali\
Advanced Python GUI Developer

------------------------------------------------------------------------

## ⭐ Project Level

Intermediate to Advanced Level\
Professional GUI Dashboard Design

------------------------------------------------------------------------

© 2026 PITP -- MUET -- Government of Sindh\
All Rights Reserved.
