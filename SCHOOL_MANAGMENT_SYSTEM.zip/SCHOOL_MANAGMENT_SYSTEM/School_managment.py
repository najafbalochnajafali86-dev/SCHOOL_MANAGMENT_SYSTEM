import sqlite3
from tkinter import *
from tkinter import ttk, messagebox

# ================= DATABASE =================
conn = sqlite3.connect("vip_school.db")
cursor = conn.cursor()

cursor.execute("""
CREATE TABLE IF NOT EXISTS students(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    age TEXT,
    class TEXT
)
""")

cursor.execute("""
CREATE TABLE IF NOT EXISTS teachers(
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT,
    subject TEXT
)
""")
conn.commit()

# ================= MAIN WINDOW =================
root = Tk()
root.title("VIP School Management Dashboard")
root.geometry("1200x700")
root.config(bg="#f4f6f9")

# ================= SIDEBAR =================
sidebar = Frame(root, bg="#1e272e", width=250)
sidebar.pack(side=LEFT, fill=Y)

Label(sidebar, text="VIP SCHOOL", bg="#1e272e",
      fg="white", font=("Arial", 20, "bold")).pack(pady=30)

# ================= MAIN AREA =================
main_frame = Frame(root, bg="#f4f6f9")
main_frame.pack(side=RIGHT, fill=BOTH, expand=True)

# ================= DASHBOARD =================
def dashboard():
    clear_frame()
    
    Label(main_frame, text="Dashboard Overview",
          font=("Arial", 24, "bold"),
          bg="#f4f6f9").pack(pady=20)

    # Cards Frame
    cards = Frame(main_frame, bg="#f4f6f9")
    cards.pack(pady=20)

    # Total Students
    cursor.execute("SELECT COUNT(*) FROM students")
    total_students = cursor.fetchone()[0]

    student_card = Frame(cards, bg="#00a8ff", width=250, height=120)
    student_card.grid(row=0, column=0, padx=20)
    Label(student_card, text="Total Students",
          bg="#00a8ff", fg="white",
          font=("Arial", 14)).pack(pady=10)
    Label(student_card, text=total_students,
          bg="#00a8ff", fg="white",
          font=("Arial", 28, "bold")).pack()

    # Total Teachers
    cursor.execute("SELECT COUNT(*) FROM teachers")
    total_teachers = cursor.fetchone()[0]

    teacher_card = Frame(cards, bg="#9c88ff", width=250, height=120)
    teacher_card.grid(row=0, column=1, padx=20)
    Label(teacher_card, text="Total Teachers",
          bg="#9c88ff", fg="white",
          font=("Arial", 14)).pack(pady=10)
    Label(teacher_card, text=total_teachers,
          bg="#9c88ff", fg="white",
          font=("Arial", 28, "bold")).pack()

# ================= CLEAR FRAME =================
def clear_frame():
    for widget in main_frame.winfo_children():
        widget.destroy()

# ================= STUDENT SECTION =================
def student_section():
    clear_frame()

    Label(main_frame, text="Student Management",
          font=("Arial", 22, "bold"),
          bg="#f4f6f9").pack(pady=20)

    form = Frame(main_frame, bg="#f4f6f9")
    form.pack()

    name_var = StringVar()
    age_var = StringVar()
    class_var = StringVar()

    Entry(form, textvariable=name_var).grid(row=0, column=0, padx=10)
    Entry(form, textvariable=age_var).grid(row=0, column=1, padx=10)
    Entry(form, textvariable=class_var).grid(row=0, column=2, padx=10)

    def add_student():
        cursor.execute("INSERT INTO students(name, age, class) VALUES(?,?,?)",
                       (name_var.get(), age_var.get(), class_var.get()))
        conn.commit()
        messagebox.showinfo("Success", "Student Added")
        show_students()

    Button(form, text="Add Student",
           bg="#27ae60", fg="white",
           command=add_student).grid(row=0, column=3, padx=10)

    table = ttk.Treeview(main_frame, columns=(1,2,3,4), show="headings")
    table.pack(pady=20, fill=X)

    table.heading(1, text="ID")
    table.heading(2, text="Name")
    table.heading(3, text="Age")
    table.heading(4, text="Class")

    def show_students():
        table.delete(*table.get_children())
        cursor.execute("SELECT * FROM students")
        for row in cursor.fetchall():
            table.insert("", END, values=row)

    show_students()

# ================= TEACHER SECTION =================
def teacher_section():
    clear_frame()

    Label(main_frame, text="Teacher Management",
          font=("Arial", 22, "bold"),
          bg="#f4f6f9").pack(pady=20)

    form = Frame(main_frame, bg="#f4f6f9")
    form.pack()

    name_var = StringVar()
    subject_var = StringVar()

    Entry(form, textvariable=name_var).grid(row=0, column=0, padx=10)
    Entry(form, textvariable=subject_var).grid(row=0, column=1, padx=10)

    def add_teacher():
        cursor.execute("INSERT INTO teachers(name, subject) VALUES(?,?)",
                       (name_var.get(), subject_var.get()))
        conn.commit()
        messagebox.showinfo("Success", "Teacher Added")
        show_teachers()

    Button(form, text="Add Teacher",
           bg="#e67e22", fg="white",
           command=add_teacher).grid(row=0, column=2, padx=10)

    table = ttk.Treeview(main_frame, columns=(1,2,3), show="headings")
    table.pack(pady=20, fill=X)

    table.heading(1, text="ID")
    table.heading(2, text="Name")
    table.heading(3, text="Subject")

    def show_teachers():
        table.delete(*table.get_children())
        cursor.execute("SELECT * FROM teachers")
        for row in cursor.fetchall():
            table.insert("", END, values=row)

    show_teachers()

# ================= SIDEBAR BUTTONS =================
Button(sidebar, text="Dashboard",
       bg="#00a8ff", fg="white",
       width=20, height=2,
       command=dashboard).pack(pady=10)

Button(sidebar, text="Students",
       bg="#27ae60", fg="white",
       width=20, height=2,
       command=student_section).pack(pady=10)

Button(sidebar, text="Teachers",
       bg="#e67e22", fg="white",
       width=20, height=2,
       command=teacher_section).pack(pady=10)

# Default Open
dashboard()

root.mainloop()